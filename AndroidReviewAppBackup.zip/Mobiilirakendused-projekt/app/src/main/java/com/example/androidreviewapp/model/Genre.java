package com.example.androidreviewapp.model;

public class Genre {


}
