package com.example.androidreviewapp.viewmodel;

import androidx.lifecycle.ViewModel;

public class GameReviewViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}