package com.example.androidreviewapp.viewmodel;

import androidx.lifecycle.ViewModel;

public class PersonalReviewViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}