package com.example.androidreviewapp.adapter;

public class GenreAdapter {
}
