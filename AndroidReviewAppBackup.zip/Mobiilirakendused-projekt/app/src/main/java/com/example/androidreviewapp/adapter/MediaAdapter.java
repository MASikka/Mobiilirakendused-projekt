package com.example.androidreviewapp.adapter;

public class MediaAdapter {

}
